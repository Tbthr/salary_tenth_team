<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
<style lang="scss">
.root{
  margin: 50px 25px 0px 25px
}
.my-flex{
  display: flex;
}
</style>
