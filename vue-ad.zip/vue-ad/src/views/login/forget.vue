<template>
    <div class="forget-wrap">
        <el-form
        class="forget-form"
        label-position="top"
        label-width="80px"
        :model="formdata">
        <h2 class="h2">忘记密码</h2>
            <el-form-item label="工号">
                <el-input v-model="formdata.userid"></el-input>
            </el-form-item>
            <el-form-item label="密码">
                <el-input v-model="formdata.password"></el-input>
            </el-form-item>
            <el-form-item label="确认密码">
                <el-input v-model="formdata.repassword"></el-input>
            </el-form-item>
            <el-button
            @click = "doSure"
            class="sure-btn" type="success" plain>确定</el-button>
            <div class="back">
                <router-link to="login" exact>返回</router-link>
            </div>
            </el-form>
    </div>
</template>

<script>
export default {
  data () {
    return {
      formdata: {
        userid: '',
        password: '',
        repassword: ''
      }
    }
  },
  methods: {
    doSure () {
      this.$router.push({name: 'login'})
    }
  }
}
</script>

<style>
.forget-wrap{
    height:100%;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    /* background: url(../../assets/images/bg.png) no-repeat; */
    background-size: 100% 100%;
}
.forget-wrap .forget-form {
    width: 280px;
    background-color: #c1dfca79;
    border-radius: 5px;
    padding:30px
}
.forget-wrap .sure-btn {
    margin-top: 40px;
    width: 100%;
}

.forget-wrap .back {
    text-align: right;
    size: 10px;
}

a {
  text-decoration: none;
  color: #1c521f80;
  font-size: 14px;
}

.router-link-active{
    text-decoration: none;
}
.el-form-item{
    margin-bottom: 0;
}
.h2{
    color: #1e4e12;
}
</style>

